# GenAi Chosen Portfolio – Prompt Suite v5.1 (Option C Normalization)

This repository-style bundle contains the full prompt set (A–D) for the GenAi Chosen portfolio workflow, upgraded to **v5.1** with:

- Per-asset base-100 normalization on the October 9, 2025 inception date.
- Chart behavior using **Option C**:
  - All assets start at 100 on inception.
  - 100 is the central reference line.
  - Y-axis is symmetric around 100 (e.g., 80 / 90 / 100 / 110 / 120).

## Structure

- `prompts/v5.1/`
  - `Prompt-A-DataEngine-v5.1A.md`
  - `Prompt-B-NarrativeWriter-v5.1B.md`
  - `Prompt-C-VisualGenerator-v5.1C.md`
  - `Prompt-D-FullPageAssembler-v5.1D.md`
- `docs/` – for future documentation and examples.
- `automation/` – for OpenAI Automations or workflow configs.
- `data_samples/` – sample `master.json` and CSV/visual outputs (you can drop them here).
- `archive/` – older prompt versions if you want to preserve them.

Use these prompts directly in ChatGPT or as system/user prompts in OpenAI Automations.
